def main():
    x = int(input("What's x? "))
    print("x squared is", square(x))

def square(x):
    return x*x

main()