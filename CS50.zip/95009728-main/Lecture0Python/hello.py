def hello(to="world"):
    print("hello,", to)

name = input("What's your name? ")
hello(name)
