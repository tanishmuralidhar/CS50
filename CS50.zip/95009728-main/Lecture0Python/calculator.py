print("Calculate the sum of two integers:")
x = float(input("What's x? "))
y = float(input("What's y? "))

z = x/y

print(f"{z:.2f}")
