Message = input("Enter text here:")
x = Message.replace(" ","...")

print(x)
