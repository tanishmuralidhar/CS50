
msg = input("Type to Emoji Converter, Type Here: ")
result = msg.replace(":)", "🙂").replace(":(", "🙁")
print(result)
