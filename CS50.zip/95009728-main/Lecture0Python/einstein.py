m = input("What is m: ")
m = int(m)
c = 300000000
c2 = int(c*c)

E = m * c2

print("E:",E)
