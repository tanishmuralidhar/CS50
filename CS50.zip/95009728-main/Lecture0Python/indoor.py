x = input("Type what you want to un capitalize: ",)
print(x.lower())