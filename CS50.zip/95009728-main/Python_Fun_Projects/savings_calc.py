savings_goal = float(input("Savings Goal: "))
initial_investment = float(input("Intial Investment: "))
years_to_grow = float(input("Year to Grow (in years): "))
interest_rate = float(input("Estimated Annual Interest rate: "))


