import statistics

avg = statistics.mean([100,90])
print(avg)