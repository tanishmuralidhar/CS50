import random

cards = ["Jack", "Queen", "king"]

random.shuffle(cards)
for card in cards:
    print(card)